

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
<div class="container">
    <div class="row">
        <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
            <div class="card card-signin my-5">
                <div class="card-header"><?php echo e(__('Admin Dashboard')); ?></div>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php echo e(__('Welcome Back Admin!')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-2 col-lg-2 col-sm-2"></div>
        <div class="col-md-4 col-lg-4 col-sm-4">
            <label style="width:100%;">
                <a href="<?php echo e(route('product')); ?>" class="img-fluid" style="text-decoration:none;color:black;">
                <div class="panel panel-default card-input card card-body bg-light">
                <img src="<?php echo e(asset('images/Product.jpg')); ?>" alt="CreditImage"><hr>
                  <div class="panel-heading"><h5>Insert Product</h5></div>
                </div>
                </a>
            </label>
        </div>
        <div class="col-md-4 col-lg-4 col-sm-4">
            <label style="width:100%;">
                <a href="<?php echo e(route('all.product')); ?>" class="img-fluid" style="text-decoration:none;color:black;">
                    <div class="panel panel-default card-input card card-body bg-light">
                        <img src="<?php echo e(asset('images/AllProduct.jpg')); ?>" alt="CashImage"><hr>
                        <div class="panel-heading"><h5>All Product</h5></div>
                    </div>
                </a>
            </label>
        </div>
        <div class="col-md-2 col-lg-2 col-sm-2"></div>
        <div class="col-md-2 col-lg-2 col-sm-2"></div>
        <div class="col-md-4 col-lg-4 col-sm-4">
            <label style="width:100%;">
                <a href="<?php echo e(route('category')); ?>" class="img-fluid" style="text-decoration:none;color:black;">
                    <div class="panel panel-default card-input card card-body bg-light">
                        <img src="<?php echo e(asset('images/Category.jpg')); ?>" alt="CreditImage"><hr>
                        <div class="panel-heading"><h5>Insert Category</h5></div>
                  </div>
                </a>
            </label>
        </div>
        <div class="col-md-4 col-lg-4 col-sm-4">
            <label style="width:100%;">
                <a href="<?php echo e(route('all.category')); ?>" class="img-fluid" style="text-decoration:none;color:black;">
                    <div class="panel panel-default card-input card card-body bg-light">
                        <img src="<?php echo e(asset('images/AllCategory.jpg')); ?>" alt="CreditImage"><hr>
                        <div class="panel-heading"><h5>All Category</h5></div>
                  </div>
                </a>
            </label>
        </div>
        <div class="col-md-2 col-lg-2 col-sm-2"></div>
        <div class="col-md-2 col-lg-2 col-sm-2"></div>
        <div class="col-md-4 col-lg-4 col-sm-4">
            <label style="width:100%;">
                <a href="<?php echo e(route('all.order')); ?>" class="img-fluid" style="text-decoration:none;color:black;">
                    <div class="panel panel-default card-input card card-body bg-light">
                        <img src="<?php echo e(asset('images/ViewOrder.jpg')); ?>" alt="CreditImage"><hr>
                        <div class="panel-heading"><h5>View Order</h5></div>
                  </div>
                </a>
            </label>
        </div>
        <div class="col-md-2 col-lg-2 col-sm-2"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supreme\supreme\resources\views/admin/index.blade.php ENDPATH**/ ?>