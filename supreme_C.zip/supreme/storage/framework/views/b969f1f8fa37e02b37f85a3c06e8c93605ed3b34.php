
<?php $__env->startSection('content'); ?> 
<script>
	var total=0;
	function Cal() {
		var prices = document.getElementsByName('price[]');		
		var cboxes = document.getElementsByName('item[]');    
		var len = cboxes.length;	    
		for (var i=0; i<len; i++) {        
			if(cboxes[i].checked){	//calculate if checked		
				subtotal=parseFloat(prices[i].value)+parseFloat(total);	
				total=subtotal;
			}else if(cboxes[i].checked == false){
				subtotal=parseFloat(prices[i].value)-parseFloat(prices[i].value);	
				// subtotal=parseFloat(total)-parseFloat(prices[i].value);	
				total=subtotal;
			}					
		}
		// total=total+subtotal;
		document.getElementById('amount').value=total.toFixed(2);
	}
</script>
<div class="container">
	    <div class="row">
			<div class="col-md-12">
				<form action="<?php echo e(route('create.order')); ?>" method="post">
                    <?php echo e(csrf_field()); ?> 
			<h3>Shopping Cart</h3><hr>
		    <table class="table table-hover table-striped" style="margin-top:5%;">
		        <thead>
					<tr class="thead-dark">
						<th>ID</th>
						<th>Image</th>
						<th>Name</th>
					
						<th>Quantity</th>
						<th>Unit Price</th>
						<th>Action</th>
					</tr>
		    	</thead>
		        <tbody>	
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            <tr>
		                <td><input type="checkbox" name="item[]" value="<?php echo e($cart->cid); ?>" onchange="Cal()" /></td>
                        <td><img src="<?php echo e(asset('images/')); ?>/<?php echo e($cart->image); ?>" alt="" width="50"></td>
		                <td style="max-width:300px">
		                    <h6><?php echo e($cart->name); ?></h6>
						</td>
						<?php 
							$subtotal=$cart->qty*$cart->price;
						?>
						<input type="hidden" value="<?php echo e($subtotal); ?>" name="price[]" id="price[]"/>
		                <input type="hidden" name="id" id="id" value="<?php echo e($cart->id); ?>">
                        <td><?php echo e($cart->qty); ?></td>
						<td>RM <?php echo e($cart->price); ?></td>
		                <td>
		                    <a href="<?php echo e(route('edit.cart', ['id' => $cart->cid])); ?>" class="btn btn-warning">Edit</a> | 
		                    <a href="<?php echo e(route('delete.cart', ['id' => $cart->cid])); ?>" class="btn btn-danger" onclick="return confirm('Sure Want Delete?')">Delete</a>
						</td>
					</tr> 
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr class="thead-dark">
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>                   
						<td>&nbsp;</td>
						<td><h5>Total: </h5></td>
						<td>RM <input type="text" name="amount" id="amount" value="0.00" readonly style="width:45%;font-size:1.0em"></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td> 
						<td>&nbsp;</td>
						<td>&nbsp;</td> 
						<td><input type="submit" name="checkout" class="btn btn-danger btn-xs text-uppercase" value="Proceed to Checkout"></td>
					</tr>
		        </tbody>
			</table>		
		</div>
	</form>
	</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\supreme\supreme\resources\views/showcart.blade.php ENDPATH**/ ?>