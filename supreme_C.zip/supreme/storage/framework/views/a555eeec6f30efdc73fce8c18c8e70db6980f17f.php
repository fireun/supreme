
<?php $__env->startSection('content'); ?> 


<div class="container">
	<form action="<?php echo e(route('updateStatus.order')); ?>" method="post">
		<?php echo e(csrf_field()); ?> 
	    <div class="row">
			<div class="col-md-12">
				<h3>User Information</h3><hr>

					<table class="table table-hover table-striped">
						<thead>
						<tr class="thead-dark">
							<th>Name</th>
							<th>Email</th>
							<th>Phone No</th>
							<th>Address</th>
							<th>City</th>
                            <th>Postal code</th>
                            <th>Country</th>
						</tr>
					</thead>
						<tbody>	
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
								<td><?php echo e($user->phoneNo); ?></td>
								<td><?php echo e($user->address); ?></td>
								<td><?php echo e($user->city); ?></td>
                                <td><?php echo e($user->postalCode); ?></td>
                                <td><?php echo e($user->country); ?></td>
							</tr> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						</tbody>
					</table>
				
			</div>
        </div>
        

        <div class="row">
			<div class="col-md-12">
				<h3>Order Information</h3><hr>

					<table class="table table-hover table-striped">
						<thead>
						<tr class="thead-dark">
							<th>Product</th>
							<th>Image</th>
                            <th>Quantity</th>
                            <th>category</th>
                            <th>Payment Status</th>
							<th>Order Date</th>
						</tr>
					</thead>
						<tbody>	
						<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
                                <td><?php echo e($order->name); ?></td>
                                <td><img src="<?php echo e(asset('images/')); ?>/<?php echo e($order->image); ?>" alt="" width="50"></td>
								<td><?php echo e($order->qty); ?></td>
								<td><?php echo e($order->categoryName); ?></td>
                                <td><?php echo e($order->paymentStatus); ?></td>
                                <td><?php echo e($order->orderDate); ?></td>
							</tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                            <tr>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td> 
                                
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $orderID = $order->orderID;
                                        $currentOrderStatus = $order->status;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td>Order Status: <?php echo e($currentOrderStatus); ?></td>
                                <td>
                                    <div class="form-group">
                                        <input type="hidden" name="orderID" value="<?php echo e($orderID); ?>">
                                        <select class="form-control" name="status">
                                            <option value="<?php echo e($currentOrderStatus); ?>"><?php echo e($currentOrderStatus); ?></option>
                                            <option value="Packging">Packging</option>
                                            <option value="Shipping">Shipping</option>
                                        </select>
                                    </div>
                                </td>
                                <td><input type="submit" name="submit" class="btn btn-danger col-md-12" value="Submit" onclick="return confirm('Sure Want Update Status?')"></td>
                            </tr>

						</tbody>
					</table>
				
			</div>
		</div>
	</form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supreme\supreme\resources\views/viewOrderDetail.blade.php ENDPATH**/ ?>