
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="container col-md-5 shadow-lg p-3 mb-5 bg-white rounded">
        <h3>Edit Product</h3><hr>
        <form class="form-horizontal" method="post" action="<?php echo e(route('update.product')); ?>" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>​
			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				<h5>Product: <?php echo e($product->name); ?></h5>
				<div class="form-group">
					<label for="ID" class="label">Product ID: </label>
					<input type="text" name="ID" id="ID" value="<?php echo e($product->id); ?>" class="form-control" readonly>
				</div>
				<div class="form-group">
					<label for="name" class="label">Title: </label>
					<input type="text" name="title" id="title" value="<?php echo e($product->name); ?>"  class="form-control">
				</div><br/>
				<div class="form-group">
					<select style="text-align:center" name="category_id" id= "category_id" class="form-control">
						<option  value="">Select Category</option>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option  value="<?php echo e($category->id); ?>" 
							<?php if($product->categoryID==$category->id): ?> 
							selected 
							<?php endif; ?>><?php echo e($category->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select> 
				</div>
				<div class="form-group">
					<label for="Quantity" class="label">Quantity: </label>
					<input name="Quantity" id="Quantity" type="text" value="<?php echo e($product->quantity); ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="price" class="label">Price: </label>
					<input name="price" id="price" type="text" value="<?php echo e($product->price); ?>" class="form-control">
				</div>
				<div class="form-group">
					<label for="Description" class="label">Description: </label>
					<textarea name="Description" id="Description" class="form-control"><?php echo e($product->description); ?></textarea>
				</div>
				<div class="form-group">
					<label for="image" class="label">Select image to upload:</label>
					<input type="file" name="product-image" id="fileToUpload">
				</div>
				<br/>
				<input type="submit" name="insert" class="btn btn-danger col-md-12" value="Update">
				<input type="submit" href="<?php echo e(route('all.product')); ?>" name="insert" class="btn col-md-12" value="Back">
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supreme\supreme\resources\views/editProduct.blade.php ENDPATH**/ ?>