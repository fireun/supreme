
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <table class="table table-hover table-striped">
            <thead>
            
            <tr class="thead-dark">
                <th>ID</th>
                <th>Image</th>
                <th style="width:50%;">Name</th>
                <th>Action</th>
            </tr>
        </thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><img src="<?php echo e(asset('images/')); ?>/<?php echo e($category->image); ?>" alt="" width="50"></td>
                    <td style="max-width:300px">
                        <h6><?php echo e($category->name); ?></h6>
                        <em class="text-muted">
                            
                        </em>
                    </td>
                    <td>
                        
                        <a href="<?php echo e(route('edit.category', ['id' => $category->id])); ?>" class="btn btn-warning"><i class="fas fa-edit">Edit</i></a> 
                        <a href="<?php echo e(route('delete.category', ['id' => $category->id])); ?>" class="btn btn-danger" onclick="return confirm('Sure Want Delete?')"><i class="fas fa-trash">Delete</i></a>
                    </td>
                </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supreme\supreme\resources\views/showcategory.blade.php ENDPATH**/ ?>