
<?php $__env->startSection('content'); ?> 


<div class="container">
	    <div class="row">
			<div class="col-md-12">
				<h3>Order</h3><hr>

					<table class="table table-hover table-striped">
						<thead>
						<tr class="thead-dark">
							<th>ID</th>
							<th>user ID</th>
							<th>Amount</th>
							<th>Order Date</th>
							<th>Status</th>
							<th>Action</th>
						</tr>
					</thead>
						<tbody>	
						<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($order->id); ?></td>
								<input type="hidden" name="orderId" value="<?php echo e($order->id); ?>">
								<td><?php echo e($order->userID); ?></td>
								<td>RM <?php echo e($order->amount); ?></td>
								<td><?php echo e($order->created_at); ?></td>
								<td>
									<?php echo e($order->status); ?>

								</td>
								<td><a href="<?php echo e(route('orderDetail.order', ['id' => $order->id])); ?>" class="btn btn-danger">View Order Detail</a></td>
							</tr> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						</tbody>
					</table>
				</form>
			</div>
		</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supreme\supreme\resources\views/viewOrder.blade.php ENDPATH**/ ?>