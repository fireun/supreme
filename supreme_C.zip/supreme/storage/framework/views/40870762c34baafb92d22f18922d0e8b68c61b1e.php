
<?php $__env->startSection('content'); ?> 


<div class="container">
	    <div class="row">
			<div class="col-md-12">
				<h3>Order</h3><hr>
				<form method="post" action="<?php echo URL::to('paypal'); ?>" >
				<?php echo e(csrf_field()); ?>

					<table class="table table-hover table-striped">
						<thead>
						<tr class="thead-dark">
							<th>ID</th>
							<th>Image</th>
							<th>Name</th>
						
							<th>Quantity</th>
							<th>Unit Price</th>
							<th>Total Price</th>
							<th>Status</th>
						</tr>
					</thead>
						<tbody>	
						<?php 
							$total=0;
						?>
						<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($order->id); ?></td>
								<td><img src="<?php echo e(asset('images/')); ?>/<?php echo e($order->image); ?>" alt="" width="50"></td>
								<td style="max-width:300px">
									<h6><?php echo e($order->name); ?></h6>
								
								</td>
								<?php 
									$subtotal=$order->qty*$order->price;
									$total=$total+$subtotal;
								?>
								<td><?php echo e($order->qty); ?></td>
								<td><?php echo e($order->price); ?></td>
								<td><?php echo e($subtotal); ?></td>
								<td>
									<?php echo e($order->paymentStatus); ?>

								</td>
							</tr> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>                   
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td><h5>Total: </h5></td>
							<td><h5>RM <?php echo e($total); ?></h5></td>
						</tr>
						<tr class="thead-dark">
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>                   
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td><input type="hidden" name="amount" value="<?php echo e($total); ?>"></td>
							<td><input type="submit" name="paynow" value="Pay Now" class="btn btn-danger btn-xs text-uppercase" style="width:100%;"></td>
						</tr>
						</tbody>
					</table>
				</form>
			</div>
		</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\supreme\supreme\resources\views/order.blade.php ENDPATH**/ ?>