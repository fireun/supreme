
<?php $__env->startSection('content'); ?>
    <div class="container"> 
        <h2 style="text-align: center;margin-top:3%;">Categories</h2><br/>
        <form action="<?php echo e(route('search.category')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="active mb-4">
                <input class="form-control" type="text" name="searchCategory" id="searchCategory" placeholder="Search" aria-label="Search">
            </div>
        </form>
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <div class="col-sm-4" style="margin-top:3%;"> 
                            <div class="card h-100">
                                <div class="card-body">
                                    <h5 class="card-title "><?php echo e($category->name); ?></h5>
                                    <a href="<?php echo e(route('categoryproduct.category', ['id' => $category->id])); ?>"><img src="<?php echo e(asset('images/')); ?>/<?php echo e($category->image); ?>" alt="" class="img-fluid" ></a>
                                </div>
                                <div class="card-footer">
                                    <a href="<?php echo e(route('categoryproduct.category', ['id' => $category->id])); ?>"><button style="float:right" class="btn btn-danger btn-xs">Learn More</button></a>
                                </div>
                            </div>
                        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>     
    </div>      
<?php $__env->stopSection(); ?>             

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\supreme\supreme\resources\views/categories.blade.php ENDPATH**/ ?>