
<?php $__env->startSection('content'); ?>                
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="container" style="margin-top:5%;">
                <form action="<?php echo e(route('add.to.cart')); ?>" method="post">
                    <?php echo e(csrf_field()); ?> 
                    <div class="col-md-6" style="float:left;"><img src="<?php echo e(asset('images/')); ?>/<?php echo e($product->image); ?>" alt="" class="img-fluid" width="500"></div>
                    
                    <div class="col-md-6" style="float:right;">
                        <h2 class="card-title"><?php echo e($product->name); ?></h2>
                            <p class="price-detail-wrap"> 
                                <span class="price h3 text-danger"> 
                                    <span class="currency">RM</span><span class="num"><?php echo e($product->price); ?></span>
                                </span> 
                            </p>
                            <dl class="item-property">
                                <dt>Description</dt>
                                <dd><p><?php echo e($product->description); ?></p></dd>
                            </dl>
                            <dl class="item-property">
                                <dt>Available stock</dt>
                                <dd><p><?php echo e($product->quantity); ?></p></dd>
                            </dl>
                            <dl class="item-property">
                                <dt>Category ID</dt>
                                <dd><p><?php echo e($product->categoryID); ?></p></dd>
                            </dl>
                            <dl class="item-property">
                                <dt>Product ID</dt>
                                <dd><p><?php echo e($product->id); ?></p></dd>
                            </dl>
                            <hr>
                            <dl class="item-property">
                                <dt>Quantity <input type="number" name="quantity" id="qty" value="1" min="1" max="10"></dt>
                            </dl>
                            <input type="hidden" name="id" id="id" value="<?php echo e($product->id); ?>">
                            <input type="hidden" id="name" name="name" value="<?php echo e($product->name); ?>">
                            <input type="hidden" id="amount" name="amount" value="">
                            <hr>
                        <button type="submit" style="float:left" class="btn btn-danger btn-xs text-uppercase btn-lg">Buy Now</button>
                    </div>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>       
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supreme\supreme\resources\views/productdetail.blade.php ENDPATH**/ ?>