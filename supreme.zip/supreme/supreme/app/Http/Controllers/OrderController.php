<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Product;
use App\User;
use App\Cart;
use App\Order;
use Auth;

Use Session;

class OrderController extends Controller
{
    public function __construct(){
        $this->middleware('role:user');
        
    }

    public function add(){ 

        $r=request(); 
        $addOrder=Order::create([    
            
            'amount'=>$r->amount,             
            'paymentStatus'=>'pending',                 
            'userID'=>Auth::id(), 
        ]);

        $orderID=DB::table('orders')->where('userID','=',Auth::id())->orderBy('created_at','desc')->first(); //get the lastest order ID

        $items=$r->input('item');
        foreach($items as $item => $value){
            $carts=Cart::find($value);
            $carts->orderID = $orderID->id;
            $carts->save();
        }

        Session::flash('success',"Order succesful!");        
        Return redirect()->route('my.order'); //redirect to payment 
    }

    public function show(){

        $orders=DB::table('orders')
        ->leftjoin('carts', 'orders.id', '=', 'carts.orderID')
        ->leftjoin('products', 'products.id', '=', 'carts.productID')
        ->select('carts.*','orders.*','products.*','carts.quantity as qty')
        ->where('orders.userID','=',Auth::id())
        ->get();     
        return view('order')->with('orders',$orders);
    }
}
