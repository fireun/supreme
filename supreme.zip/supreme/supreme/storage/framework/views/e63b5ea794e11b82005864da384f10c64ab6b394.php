
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="container col-md-5 shadow-lg p-3 mb-5 bg-white rounded">
        <h3>Edit Category</h3><hr>
        <form class="form-horizontal" method="post" action="<?php echo e(route('update.category')); ?>" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>​
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				<h5>Category: <?php echo e($category->name); ?></h5>
				<div class="form-group">
					<label for="ID" class="label">Category ID: </label>
					<input type="text" name="ID" id="ID" value="<?php echo e($category->id); ?>" class="form-control" readonly>
				</div>
				<div class="form-group">
					<label for="name" class="label">Title: </label>
					<input type="text" name="title" id="title" value="<?php echo e($category->name); ?>"  class="form-control">
				</div><br/>
				<div class="form-group">
					<label for="image" class="label">Select image to upload:</label>
					<input type="file" name="category-image" id="fileToUpload">
				</div>
				<br/>
                <input type="submit" name="insert" class="btn btn-danger col-md-12" value="Update">
                <input type="submit" href="<?php echo e(route('all.category')); ?>" name="insert" class="btn col-md-12" value="Back">
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\supreme\supreme\resources\views/editCategory.blade.php ENDPATH**/ ?>