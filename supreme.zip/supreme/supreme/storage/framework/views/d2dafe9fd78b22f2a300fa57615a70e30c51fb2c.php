
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="container col-md-5 shadow-lg p-3 mb-5 bg-white rounded">
        <h3>Edit Quantity</h3><hr>
        <form class="form-horizontal" method="post" action="<?php echo e(route('update.cart')); ?>" enctype="multipart/form-data">
			<?php echo e(csrf_field()); ?>​
            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				<div class="form-group">
					<label for="id" class="label">Cart ID: </label>
					<input type="text" name="id" id="id" value="<?php echo e($cart->id); ?>" class="form-control" readonly>
				</div>
			
				<div class="form-group">
					<label for="quantity" class="label">Quantity: </label>
					<input name="quantity" id="quantity" type="text" value="<?php echo e($cart->quantity); ?>" class="form-control">
				</div>
				<br/>
				<input type="submit" name="insert" class="btn btn-danger col-md-12" value="Update">
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\supreme\supreme\resources\views/editcart.blade.php ENDPATH**/ ?>