
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <table class="table table-hover table-striped">
            <thead>
            
            <tr class="thead-dark">
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Category</th>
            </tr>
        </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><img src="<?php echo e(asset('images/')); ?>/<?php echo e($product->image); ?>" alt="" width="50"></td>
                    <td style="max-width:300px">
                        <h6><?php echo e($product->name); ?></h6>
                        <em class="text-muted">
                            <?php echo e($product->description); ?>

                        </em>
                    </td>
                    <td><?php echo e($product->catname); ?></td>
                    <td><?php echo e($product->quantity); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td>
                        
                        <a href="<?php echo e(route('edit.product', ['id' => $product->id])); ?>" class="btn btn-warning"><i class="fas fa-edit">Edit</i></a> 
                        <a href="<?php echo e(route('delete.product', ['id' => $product->id])); ?>" class="btn btn-danger" onclick="return confirm('Sure Want Delete?')"><i class="fas fa-trash">Delete</i></a>
                    </td>
                </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
            </tbody>
        </table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\supreme\supreme\resources\views/showproduct.blade.php ENDPATH**/ ?>